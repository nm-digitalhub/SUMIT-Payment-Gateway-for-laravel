<?php

declare(strict_types=1);

namespace OfficeGuy\LaravelSumitGateway\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use OfficeGuy\LaravelSumitGateway\Contracts\Payable;

/**
 * CheckoutRequest - Form Request for checkout validation
 *
 * Centralizes all checkout validation logic.
 * Includes conditional validation based on PayableType requirements.
 *
 * Previously: Validation was inline in PublicCheckoutController (lines 170-206)
 * Now: Extracted to dedicated Form Request for reusability and testability
 *
 * @package OfficeGuy\LaravelSumitGateway
 * @since 1.2.0
 */
class CheckoutRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize(): bool
    {
        // Authorization is handled at controller level
        // (checking if public checkout is enabled, etc.)
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        $rules = [
            // Customer information
            'customer_name' => 'required|string|max:255',
            'customer_email' => 'required|email|max:255',
            'customer_phone' => 'required|string|max:50',

            // Payment preferences
            'payment_method' => 'required|in:card,bit',
            'payments_count' => 'nullable|integer|min:1|max:36',
            'payment_token' => 'nullable|string',
            'save_card' => 'nullable|boolean',

            // Business information (optional)
            'customer_company' => 'nullable|string|max:255',
            'customer_vat' => 'nullable|string|max:50',
            'citizen_id' => 'nullable|string|max:50',

            // Address fields (conditional - see below)
            'customer_address' => $this->getAddressRule(),
            'customer_address2' => 'nullable|string|max:255',
            'customer_city' => $this->getAddressRule('city'),
            'customer_state' => 'nullable|string|max:120',
            'customer_country' => $this->getAddressRule('country'),
            'customer_postal' => $this->getAddressRule('postal'),

            // Guest registration (optional)
            'password' => 'nullable|string|confirmed|min:8',
            'accept_terms' => 'accepted',
        ];

        return $rules;
    }

    /**
     * Get validation rule for address field based on PayableType requirements
     *
     * @param string $field The address field (address, city, country, postal)
     * @return string Validation rule
     */
    protected function getAddressRule(string $field = 'address'): string
    {
        // Try to get payable from route or request
        $payable = $this->getPayable();

        // If we have payable and it requires address → make it required
        if ($payable && $payable->getPayableType()->requiresAddress()) {
            return match ($field) {
                'address' => 'required|string|max:255',
                'city' => 'required|string|max:120',
                'country' => 'required|string|max:2',
                'postal' => 'required|string|max:20',
                default => 'nullable|string',
            };
        }

        // Check if user's client profile is missing this field
        // (Backward compatibility with existing logic)
        if ($client = auth()->user()?->client) {
            return $this->getClientBasedRule($client, $field);
        }

        // Default: nullable
        return match ($field) {
            'address' => 'nullable|string|max:255',
            'city' => 'nullable|string|max:120',
            'country' => 'nullable|string|max:2',
            'postal' => 'nullable|string|max:20',
            default => 'nullable|string',
        };
    }

    /**
     * Get validation rule based on client profile completeness
     * (Backward compatibility with existing behavior)
     *
     * @param mixed $client
     * @param string $field
     * @return string
     */
    protected function getClientBasedRule($client, string $field): string
    {
        $fieldMap = [
            'address' => 'client_address',
            'city' => 'client_city',
            'country' => 'client_country',
            'postal' => 'client_postal_code',
        ];

        $clientField = $fieldMap[$field] ?? null;

        if ($clientField && empty($client->{$clientField})) {
            // Client profile missing this field → require it
            return match ($field) {
                'address' => 'required|string|max:255',
                'city' => 'required|string|max:120',
                'country' => 'required|string|max:2',
                'postal' => 'required|string|max:20',
                default => 'nullable|string',
            };
        }

        // Client has this field → optional
        return match ($field) {
            'address' => 'nullable|string|max:255',
            'city' => 'nullable|string|max:120',
            'country' => 'nullable|string|max:2',
            'postal' => 'nullable|string|max:20',
            default => 'nullable|string',
        };
    }

    /**
     * Get the Payable entity from route parameters
     *
     * This method tries to resolve the payable from:
     * 1. Route binding (if 'payable' is in route)
     * 2. Custom resolver in route (if set by controller)
     *
     * @return Payable|null
     */
    protected function getPayable(): ?Payable
    {
        // Try to get from route binding
        if ($this->route('payable') instanceof Payable) {
            return $this->route('payable');
        }

        // Try to get from custom resolver (set by controller before validation)
        if ($this->has('_payable') && $this->get('_payable') instanceof Payable) {
            return $this->get('_payable');
        }

        return null;
    }

    /**
     * Get custom attributes for validator errors.
     *
     * @return array<string, string>
     */
    public function attributes(): array
    {
        return [
            'customer_name' => __('customer name'),
            'customer_email' => __('email'),
            'customer_phone' => __('phone'),
            'payment_method' => __('payment method'),
            'payments_count' => __('number of payments'),
            'customer_address' => __('address'),
            'customer_city' => __('city'),
            'customer_country' => __('country'),
            'customer_postal' => __('postal code'),
            'accept_terms' => __('terms and conditions'),
        ];
    }
}
