<?php

declare(strict_types=1);

namespace OfficeGuy\LaravelSumitGateway\Services;

use OfficeGuy\LaravelSumitGateway\Contracts\Payable;
use OfficeGuy\LaravelSumitGateway\Models\OfficeGuyDocument;
use OfficeGuy\LaravelSumitGateway\Models\OfficeGuyToken;
use OfficeGuy\LaravelSumitGateway\Models\OfficeGuyTransaction;
use OfficeGuy\LaravelSumitGateway\Support\RequestHelpers;

/**
 * Payment Service
 *
 * 1:1 port of OfficeGuyPayment.php from WooCommerce plugin
 * Handles payment processing, document creation, and order management
 */
class PaymentService
{
    /**
     * Get credentials array for API requests
     *
     * Port of: GetCredentials($Gateway)
     *
     * @return array
     */
    public static function getCredentials(): array
    {
        return [
            'CompanyID' => config('officeguy.company_id'),
            'APIKey' => config('officeguy.private_key'),
        ];
    }

    /**
     * Get maximum number of payments/installments allowed for an order value
     *
     * Port of: GetMaximumPayments($Gateway, $OrderValue)
     *
     * @param float $orderValue Order total amount
     * @return int Maximum number of installments
     */
    public static function getMaximumPayments(float $orderValue): int
    {
        $maximumPayments = (int)config('officeguy.max_payments', 1);

        $minAmountPerPayment = (float)config('officeguy.min_amount_per_payment', 0);
        if ($minAmountPerPayment > 0) {
            $maximumPayments = min($maximumPayments, (int)floor($orderValue / $minAmountPerPayment));
        }

        $minAmountForPayments = (float)config('officeguy.min_amount_for_payments', 0);
        if ($minAmountForPayments > 0 && round($orderValue) < round($minAmountForPayments)) {
            $maximumPayments = 1;
        }

        // Allow filtering via events/hooks
        // $maximumPayments = apply_filters('sumit_maximum_installments', $maximumPayments, $orderValue);

        return $maximumPayments;
    }

    /**
     * Get VAT rate from order
     *
     * Port of: GetOrderVatRate($Order)
     *
     * @param Payable $order Order instance
     * @return string VAT rate as string percentage
     */
    public static function getOrderVatRate(Payable $order): string
    {
        if (!$order->isTaxEnabled()) {
            return '';
        }

        $vatRate = $order->getVatRate();
        if ($vatRate === null) {
            return '0';
        }

        return (string)$vatRate;
    }

    /**
     * Get document language based on configuration
     *
     * Port of: GetOrderLanguage($Gateway)
     *
     * @return string Language code
     */
    public static function getOrderLanguage(): string
    {
        if (!config('officeguy.automatic_languages', true)) {
            return '';
        }

        $locale = app()->getLocale();

        return match ($locale) {
            'en', 'en_US' => 'English',
            'ar', 'ar_AR' => 'Arabic',
            'es', 'es_ES' => 'Spanish',
            'he', 'he_IL' => 'Hebrew',
            default => '',
        };
    }

    /**
     * Get customer data array from order
     *
     * Port of: GetOrderCustomer($Gateway, $Order)
     *
     * @param Payable $order Order instance
     * @param string|null $citizenId Optional citizen ID from request
     * @return array Customer data for API
     */
    public static function getOrderCustomer(Payable $order, ?string $citizenId = null): array
    {
        $customerName = $order->getCustomerName();
        $company = $order->getCustomerCompany();

        if (!empty($company)) {
            $customerName = $company . ' - ' . $customerName;
        }

        if (empty(trim($customerName))) {
            $customerName = __('Guest');
        }

        $address = $order->getCustomerAddress();
        $vatRate = self::getOrderVatRate($order);

        $customer = [
            'Name' => $customerName,
            'EmailAddress' => $order->getCustomerEmail(),
            'Phone' => $order->getCustomerPhone(),
            'ExternalIdentifier' => $order->getCustomerId() ?: '',
            'SearchMode' => config('officeguy.merge_customers', false) ? 'Automatic' : 'None',
        ];

        if ($address) {
            $customer['Address'] = $address['address'] ?? '';
            if (!empty($address['address2'])) {
                $customer['Address'] = trim($customer['Address'] . ', ' . $address['address2']);
            }

            $customer['City'] = $address['city'] ?? '';
            if (!empty($address['state'])) {
                $customer['City'] = empty($customer['City'])
                    ? $address['state']
                    : $customer['City'] . ', ' . $address['state'];
            }

            if (!empty($address['country']) && $address['country'] !== 'IL') {
                $customer['City'] = empty($customer['City'])
                    ? $address['country']
                    : $customer['City'] . ', ' . $address['country'];
            }

            $customer['ZipCode'] = $address['zip_code'] ?? '';
        }

        if ($citizenId) {
            $customer['CompanyNumber'] = $citizenId;
        }

        if ($vatRate === '0') {
            $customer['NoVAT'] = true;
        } elseif ($vatRate !== '') {
            $customer['NoVAT'] = false;
        }

        // Allow filtering via events
        // $customer = apply_filters('sumit_customer_fields', $customer, $order);

        return $customer;
    }

    /**
     * Check if currency is supported
     *
     * Port of: IsCurrencySupported()
     *
     * @param string $currency Currency code
     * @return bool
     */
    public static function isCurrencySupported(string $currency): bool
    {
        return in_array($currency, config('officeguy.supported_currencies', []));
    }

    /**
     * Get payment order items array from order
     *
     * Port of: GetPaymentOrderItems($Order)
     *
     * @param Payable $order Order instance
     * @return array Items array for API request
     */
    public static function getPaymentOrderItems(Payable $order): array
    {
        $items = [];
        $total = 0;

        // Add line items
        foreach ($order->getLineItems() as $lineItem) {
            $unitPrice = round($lineItem['unit_price'], 2);
            $quantity = $lineItem['quantity'];

            $item = [
                'Item' => [
                    'ExternalIdentifier' => $lineItem['variation_id'] ?: $lineItem['product_id'],
                    'Name' => $lineItem['name'],
                    'SKU' => $lineItem['sku'] ?? '',
                    'SearchMode' => 'Automatic',
                ],
                'Quantity' => $quantity,
                'UnitPrice' => $unitPrice,
                'Currency' => $order->getPayableCurrency(),
                'Duration_Days' => '0',
                'Duration_Months' => '0',
                'Recurrence' => '0',
            ];

            // Allow filtering via events
            // $item = apply_filters('sumit_item_fields', $item, $lineItem, $order);

            $items[] = $item;
            $total += $unitPrice * $quantity;
        }

        // Add fees
        foreach ($order->getFees() as $fee) {
            $items[] = [
                'Item' => [
                    'Name' => $fee['name'],
                    'SearchMode' => 'Automatic',
                ],
                'UnitPrice' => round($fee['amount'], 2),
                'Currency' => $order->getPayableCurrency(),
            ];
            $total += $fee['amount'];
        }

        // Add shipping
        $shippingAmount = $order->getShippingAmount();
        $shippingMethod = $order->getShippingMethod();
        if ($shippingAmount > 0 && !empty($shippingMethod)) {
            $items[] = [
                'Item' => [
                    'Name' => $shippingMethod,
                    'SearchMode' => 'Automatic',
                ],
                'Quantity' => 1,
                'UnitPrice' => round($shippingAmount, 2),
                'Currency' => $order->getPayableCurrency(),
            ];
            $total += round($shippingAmount, 2);
        }

        // Add missing amount adjustment if needed
        $missingAmount = round($order->getPayableAmount() - $total, 2);
        if ($missingAmount != 0) {
            $missingAmountName = $missingAmount < 0
                ? __('General credit')
                : __('General');

            $items[] = [
                'Item' => [
                    'Name' => $missingAmountName,
                    'SearchMode' => 'Automatic',
                ],
                'Quantity' => 1,
                'UnitPrice' => $missingAmount,
                'Currency' => $order->getPayableCurrency(),
            ];
        }

        return $items;
    }

    /**
     * Get document order items array (for invoice/receipt creation)
     *
     * Port of: GetDocumentOrderItems($Order)
     *
     * @param Payable $order Order instance
     * @return array Items array for document API request
     */
    public static function getDocumentOrderItems(Payable $order): array
    {
        $items = [];
        $total = 0;

        // Add line items
        foreach ($order->getLineItems() as $lineItem) {
            $unitPrice = round($lineItem['unit_price'], 2);
            $quantity = $lineItem['quantity'];

            $itemDetails = [
                'ExternalIdentifier' => $lineItem['variation_id'] ?: $lineItem['product_id'],
                'Name' => $lineItem['name'],
                'SKU' => $lineItem['sku'] ?? '',
                'SearchMode' => 'Automatic',
            ];

            // Allow filtering
            // $itemDetails = apply_filters('sumit_item_fields', $itemDetails, $lineItem, $order);

            $items[] = [
                'Item' => $itemDetails,
                'Quantity' => $quantity,
                'DocumentCurrency_UnitPrice' => $unitPrice,
            ];

            $total += $quantity * $unitPrice;
        }

        // Add fees
        foreach ($order->getFees() as $fee) {
            $items[] = [
                'Item' => [
                    'Name' => $fee['name'],
                    'SearchMode' => 'Automatic',
                ],
                'DocumentCurrency_UnitPrice' => round($fee['amount'], 2),
            ];
            $total += $fee['amount'];
        }

        // Add shipping
        $shippingAmount = $order->getShippingAmount();
        $shippingMethod = $order->getShippingMethod();
        if ($shippingAmount > 0) {
            $items[] = [
                'Item' => [
                    'Name' => $shippingMethod ?? __('Shipping'),
                    'SearchMode' => 'Automatic',
                ],
                'DocumentCurrency_UnitPrice' => round($shippingAmount, 2),
            ];
            $total += round($shippingAmount, 2);
        }

        // Add missing amount adjustment
        $missingAmount = round($order->getPayableAmount() - $total, 2);
        if ($missingAmount != 0) {
            $missingAmountName = $missingAmount < 0
                ? __('General credit')
                : __('General');

            $items[] = [
                'Item' => [
                    'Name' => $missingAmountName,
                    'SearchMode' => 'Automatic',
                ],
                'Quantity' => 1,
                'DocumentCurrency_UnitPrice' => $missingAmount,
                'Currency' => $order->getPayableCurrency(),
            ];
        }

        return $items;
    }

    /**
     * Build charge request for card/redirect payments.
     * Mirrors GetOrderRequest logic from the Woo plugin.
     *
     * @param Payable $order
     * @param int $paymentsCount
     * @param bool $recurring
     * @param bool $redirectMode
     * @param OfficeGuyToken|null $token
     * @param array $extra Additional request overrides
     * @return array
     */
    public static function buildChargeRequest(
        Payable $order,
        int $paymentsCount = 1,
        bool $recurring = false,
        bool $redirectMode = false,
        ?OfficeGuyToken $token = null,
        array $extra = []
    ): array {
        $orderTotal = round($order->getPayableAmount(), 2);

        $authorizeOnly = config('officeguy.authorize_only', false) || config('officeguy.testing', false);

        $request = [
            'Credentials'          => self::getCredentials(),
            'Items'                => self::getPaymentOrderItems($order),
            'VATIncluded'          => 'true',
            'VATRate'              => self::getOrderVatRate($order),
            'Customer'             => self::getOrderCustomer($order, RequestHelpers::post('og-citizenid')),
            'AuthoriseOnly'        => $authorizeOnly ? 'true' : 'false',
            'DraftDocument'        => config('officeguy.draft_document', false) ? 'true' : 'false',
            'SendDocumentByEmail'  => config('officeguy.email_document', true) ? 'true' : 'false',
            'UpdateCustomerByEmail'=> config('officeguy.email_document', true) ? 'true' : 'false',
            'UpdateCustomerOnSuccess' => config('officeguy.email_document', true) ? 'true' : 'false',
            'DocumentDescription'  => __('Order number') . ': ' . $order->getPayableId() .
                (empty($order->getCustomerNote()) ? '' : "\r\n" . $order->getCustomerNote()),
            'Payments_Count'       => $paymentsCount,
            'MaximumPayments'      => self::getMaximumPayments($orderTotal),
            'DocumentLanguage'     => self::getOrderLanguage(),
            'MerchantNumber'       => $recurring
                ? config('officeguy.subscriptions_merchant_number')
                : config('officeguy.merchant_number'),
        ];

        if ($authorizeOnly) {
            $request['AutoCapture'] = 'false';
            $authorizeAmount = $orderTotal;
            $percent = config('officeguy.authorize_added_percent');
            if ($percent !== null) {
                $authorizeAmount = round($authorizeAmount * (1 + ((float)$percent) / 100), 2);
            }
            $minAddition = config('officeguy.authorize_minimum_addition');
            if ($minAddition !== null && ($authorizeAmount - $orderTotal) < (float)$minAddition) {
                $authorizeAmount = round($orderTotal + (float)$minAddition, 2);
            }
            $request['AuthorizeAmount'] = $authorizeAmount;
        }

        if ($redirectMode) {
            // Caller must set RedirectURL / CancelRedirectURL in $extra
        } else {
            // Build payment method based on PCI mode
            $pciMode = config('officeguy.pci', 'no');

            if ($token) {
                $request['PaymentMethod'] = TokenService::getPaymentMethodFromToken($token);
            } elseif ($pciMode === 'yes') {
                $request['PaymentMethod'] = TokenService::getPaymentMethodPCI();
            } else {
                $request['PaymentMethod'] = [
                    'SingleUseToken' => RequestHelpers::post('og-token'),
                    'Type'           => 1,
                ];
            }
        }

        return array_merge($request, $extra);
    }

    /**
     * Process a card/redirect charge.
     * Returns array with keys: success(bool), redirect_url?, message?, payment?, response?
     */
    public static function processCharge(
        Payable $order,
        int $paymentsCount = 1,
        bool $recurring = false,
        bool $redirectMode = false,
        ?OfficeGuyToken $token = null,
        array $extra = []
    ): array {
        $environment = config('officeguy.environment', 'www');

        $request = self::buildChargeRequest($order, $paymentsCount, $recurring, $redirectMode, $token, $extra);

        $endpoint = '/billing/payments/charge/';
        if ($recurring) {
            $endpoint = '/billing/recurring/charge/';
        } elseif ($redirectMode) {
            $endpoint = '/billing/payments/beginredirect/';
        }

        $response = OfficeGuyApi::post($request, $endpoint, $environment, !$recurring);

        // Redirect flow
        if ($redirectMode) {
            if ($response && isset($response['Data']['RedirectURL'])) {
                return [
                    'success' => true,
                    'redirect_url' => $response['Data']['RedirectURL'],
                    'response' => $response,
                ];
            }

            return [
                'success' => false,
                'message' => __('Something went wrong.'),
                'response' => $response,
            ];
        }

        if (!$response) {
            return [
                'success' => false,
                'message' => __('Payment failed') . ' - ' . __('No response'),
            ];
        }

        $status = $response['Status'] ?? null;
        $payment = $response['Data']['Payment'] ?? null;

        if ($status === 0 && $payment && ($payment['ValidPayment'] ?? false) === true) {
            // Persist transaction
            OfficeGuyTransaction::create([
                'order_id' => $order->getPayableId(),
                'payment_id' => $payment['ID'] ?? null,
                'document_id' => $response['Data']['DocumentID'] ?? null,
                'customer_id' => $response['Data']['CustomerID'] ?? null,
                'auth_number' => $payment['AuthNumber'] ?? null,
                'amount' => $payment['Amount'] ?? $order->getPayableAmount(),
                'first_payment_amount' => $payment['FirstPaymentAmount'] ?? null,
                'non_first_payment_amount' => $payment['NonFirstPaymentAmount'] ?? null,
                'status' => 'completed',
                'status_description' => $payment['StatusDescription'] ?? null,
                'payment_method' => 'card',
                'last_digits' => $payment['PaymentMethod']['CreditCard_LastDigits'] ?? null,
                'expiration_month' => $payment['PaymentMethod']['CreditCard_ExpirationMonth'] ?? null,
                'expiration_year' => $payment['PaymentMethod']['CreditCard_ExpirationYear'] ?? null,
                'raw_request' => $request,
                'raw_response' => $response,
                'environment' => $environment,
                'is_test' => config('officeguy.testing', false),
            ]);

            event(new \OfficeGuy\LaravelSumitGateway\Events\PaymentCompleted(
                $order->getPayableId(),
                $payment,
                $response
            ));

            return [
                'success' => true,
                'payment' => $payment,
                'response' => $response,
            ];
        }

        if ($status !== 0) {
            event(new \OfficeGuy\LaravelSumitGateway\Events\PaymentFailed(
                $order->getPayableId(),
                $response,
                $response['UserErrorMessage'] ?? 'Gateway error'
            ));
            return [
                'success' => false,
                'message' => __('Payment failed') . ' - ' . ($response['UserErrorMessage'] ?? 'Gateway error'),
                'response' => $response,
            ];
        }

        // Decline
        event(new \OfficeGuy\LaravelSumitGateway\Events\PaymentFailed(
            $order->getPayableId(),
            $response,
            $payment['StatusDescription'] ?? 'Declined'
        ));
        return [
            'success' => false,
            'message' => __('Payment failed') . ' - ' . ($payment['StatusDescription'] ?? 'Declined'),
            'response' => $response,
        ];
    }
}
