<?php

declare(strict_types=1);

namespace OfficeGuy\LaravelSumitGateway\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Route;
use OfficeGuy\LaravelSumitGateway\Models\OfficeGuyTransaction;
use OfficeGuy\LaravelSumitGateway\Services\DocumentService;
use OfficeGuy\LaravelSumitGateway\Services\OfficeGuyApi;
use OfficeGuy\LaravelSumitGateway\Services\PaymentService;
use OfficeGuy\LaravelSumitGateway\Support\OrderResolver;

/**
 * Card Callback Controller
 *
 * Handles redirect callbacks from SUMIT after card payment processing
 * Port of: ProcessRedirectResponse() and ThankYou() logic
 */
class CardCallbackController extends Controller
{
    /**
     * Handle the payment callback
     *
     * Port of: ThankYou($OrderID) from OfficeGuyPayment.php
     * and ProcessRedirectResponse() from officeguy_woocommerce_gateway.php
     */
    public function handle(Request $request)
    {
        $orderId    = $request->query('OG-OrderID');
        $paymentId  = $request->query('OG-PaymentID');
        $documentId = $request->query('OG-DocumentID');

        if (empty($orderId) || empty($paymentId)) {
            OfficeGuyApi::writeToLog('Card callback received without required parameters', 'error');
            return $this->redirectFailed(__('Invalid payment callback'));
        }

        OfficeGuyApi::writeToLog('Processing card callback for order #' . $orderId, 'debug');

        $order = OrderResolver::resolve($orderId);

        // Find existing transaction or create pending
        $transaction = OfficeGuyTransaction::where('order_id', $orderId)
            ->where('status', 'pending')
            ->first();

        if (!$transaction) {
            $transaction = new OfficeGuyTransaction([
                'order_id'      => $orderId,
                'payment_id'    => $paymentId,
                'status'        => 'pending',
                'payment_method'=> 'card',
                'environment'   => config('officeguy.environment', 'www'),
                'is_test'       => config('officeguy.testing', false),
            ]);
        }

        // Get payment details from SUMIT
        $paymentRequest = [
            'Credentials' => PaymentService::getCredentials(),
            'PaymentID'   => $paymentId,
        ];

        $environment = config('officeguy.environment', 'www');
        $response    = OfficeGuyApi::post($paymentRequest, '/billing/payments/get/', $environment, false);

        if ($response === null) {
            OfficeGuyApi::writeToLog('Failed to get payment details for payment #' . $paymentId, 'error');
            return $this->redirectFailed(__('Failed to verify payment'));
        }

        $payment = $response['Data']['Payment'] ?? null;

        if (!$payment || ($payment['ValidPayment'] ?? false) !== true) {
            $statusDescription = $payment['StatusDescription'] ?? 'Unknown error';

            $transaction->status            = 'failed';
            $transaction->status_description = $statusDescription;
            $transaction->error_message     = $statusDescription;
            $transaction->raw_response      = $response;
            $transaction->save();

            OfficeGuyApi::writeToLog(
                'Payment failed for order #' . $orderId . ': ' . $statusDescription,
                'error'
            );

            return $this->redirectFailed(__('Payment failed') . ' - ' . $statusDescription);
        }

        $paymentMethod = $payment['PaymentMethod'] ?? [];

        $transaction->fill([
            'payment_id'             => $payment['ID'] ?? null,
            'document_id'            => $documentId,
            'customer_id'            => $payment['CustomerID'] ?? null,
            'auth_number'            => $payment['AuthNumber'] ?? null,
            'amount'                 => $payment['Amount'] ?? ($order ? $order->getPayableAmount() : 0),
            'first_payment_amount'   => $payment['FirstPaymentAmount'] ?? null,
            'non_first_payment_amount' => $payment['NonFirstPaymentAmount'] ?? null,
            'status'                 => 'completed',
            'last_digits'            => $paymentMethod['CreditCard_LastDigits'] ?? null,
            'expiration_month'       => $paymentMethod['CreditCard_ExpirationMonth'] ?? null,
            'expiration_year'        => $paymentMethod['CreditCard_ExpirationYear'] ?? null,
            'status_description'     => $payment['StatusDescription'] ?? null,
            'raw_response'           => $response,
        ]);
        $transaction->save();

        OfficeGuyApi::writeToLog(
            'Payment completed for order #' . $orderId .
            '. Auth: ' . ($payment['AuthNumber'] ?? 'N/A') .
            ', Last digits: ' . ($paymentMethod['CreditCard_LastDigits'] ?? 'N/A') .
            ', Payment ID: ' . $payment['ID'] .
            ', Document ID: ' . $documentId,
            'info'
        );

        // Create order document if configured and order is available
        if (config('officeguy.create_order_document', false) && $order) {
            $customer = PaymentService::getOrderCustomer($order);
            DocumentService::createOrderDocument($order, $customer, $documentId);
        }

        return $this->redirectSuccess($orderId, __('Payment completed successfully'));
    }

    private function redirectSuccess(string|int $orderId, string $message)
    {
        $route = config('officeguy.routes.success', 'checkout.success');

        if ($route && Route::has($route)) {
            return redirect()->route($route, ['order' => $orderId])->with('success', $message);
        }

        return redirect()->to(url('/'))->with('success', $message);
    }

    private function redirectFailed(string $message)
    {
        $route = config('officeguy.routes.failed', 'checkout.failed');

        if ($route && Route::has($route)) {
            return redirect()->route($route)->with('error', $message);
        }

        return redirect()->to(url('/'))->with('error', $message);
    }
}
